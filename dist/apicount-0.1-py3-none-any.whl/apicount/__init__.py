"""
apicount shows list of apis and count

"""

import os
import sys


__all__ = ["apicount"]

from . import apicount

__version__="0.1"

